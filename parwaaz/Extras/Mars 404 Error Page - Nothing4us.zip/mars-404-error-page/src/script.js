// design from 
// https://www.uplabs.com/posts/404-page-ec3ed676-77f6-49c1-9134-83a5fa17c17b